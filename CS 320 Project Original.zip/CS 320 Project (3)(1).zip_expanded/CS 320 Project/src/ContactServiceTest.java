
public class ContactServiceTest {

}
